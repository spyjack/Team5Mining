﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "New Upgrade", menuName = "Vehicle Parts/Upgrade", order = 51)]
public class PartUpgrade : PartBase
{

    //Not quite sure how to implement this one
}