﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using UnityEngine;

public class MainMenu : MonoBehaviour
{
    [Header("Level1Name")]
    public string nextLevel;
    [Header("Panels")]
    public GameObject helpPanel;
    public GameObject creditsPanel;

    /*[Header("Buttons")]
    public Button startButton;
    public Button helpButton;
    public Button creditsButton;
    public Button
    */


    public void OnClickStart()
    {
        SceneManager.LoadScene(nextLevel);
    }
    public void OnClickHelp()
    {
        helpPanel.SetActive(true);
    }
    public void OnClickHelpPanelButton()
    {
        helpPanel.SetActive(false);
    }
    public void OnClickCredits()
    {
        creditsPanel.SetActive(true);
    }
    public void OnClickCreditsPanelButton()
    {
        creditsPanel.SetActive(false);
    }
    public void OnClickQuit()
    {
        Application.Quit();
        print("Quit button was pressed");
    }
}
